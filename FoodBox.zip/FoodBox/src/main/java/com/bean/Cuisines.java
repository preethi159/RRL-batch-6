package com.bean;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
@Entity
public class Cuisines {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	
	private int id;
	private String name;

    @OneToMany
    @JoinColumn(name="fid")
	List<Food> listOfFood;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Food> getListOfFood() {
		return listOfFood;
	}

	public void setListOfFood(List<Food> listOfFood) {
		this.listOfFood = listOfFood;
	}

	public Cuisines(int id, String name, List<Food> listOfFood) {
		super();
		this.id = id;
		this.name = name;
		this.listOfFood = listOfFood;
	}

	public Cuisines() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Cuisines [id=" + id + ", name=" + name + ", listOfFood=" + listOfFood + "]";
	}
	
}
