export class Cuisines {
    constructor(public id:number,public name:string){}
}
