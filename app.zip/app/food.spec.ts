import { Food } from './food';

describe('Food', () => {
  it('should create an instance', () => {
    expect(new Food()).toBeTruthy();
  });
});
