import { Cuisines } from './cuisines';

describe('Cuisines', () => {
  it('should create an instance', () => {
    expect(new Cuisines()).toBeTruthy();
  });
});
