export class Food {
    constructor(public id:number,public name:string,public description:string,public price:number,public offer:number,
       public url:string, public fid:number){}
}
