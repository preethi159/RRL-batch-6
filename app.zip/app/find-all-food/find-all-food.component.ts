import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-find-all-food',
  templateUrl: './find-all-food.component.html',
  styleUrls: ['./find-all-food.component.css']
})
export class FindAllFoodComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
